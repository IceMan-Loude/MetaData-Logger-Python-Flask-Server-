from flask import Flask, request
import smtplib
from email.mime.text import MIMEText
import logging
import os

app = Flask(__name__)

# Configure logging
logging.basicConfig(filename='access.log', level=logging.INFO)

# Email configuration (update with your SMTP settings)
EMAIL_ADDRESS = "your-email@example.com"
EMAIL_PASSWORD = "your-email-password"
TO_EMAIL = "pass.alpaca511@eagereverest.com"

@app.route('/verify-resume')
def track_access():
    # Collect metadata
    ip_address = request.remote_addr
    user_agent = request.user_agent.string
    timestamp = request.date.strftime('%Y-%m-%d %H:%M:%S')
    
    # Log metadata
    log_message = f"IP: {ip_address}, User-Agent: {user_agent}, Time: {timestamp}"
    logging.info(log_message)
    
    # Send email report
    try:
        msg = MIMEText(log_message)
        msg['Subject'] = 'Resume Access Report'
        msg['From'] = EMAIL_ADDRESS
        msg['To'] = TO_EMAIL
        
        with smtplib.SMTP_SSL('smtp.example.com', 465) as smtp_server:
            smtp_server.login(EMAIL_ADDRESS, EMAIL_PASSWORD)
            smtp_server.sendmail(EMAIL_ADDRESS, TO_EMAIL, msg.as_string())
    except Exception as e:
        logging.error(f"Email sending failed: {e}")
    
    # Return a simple response
    return """
    <h1>Resume Verification</h1>
    <p>Metadata logged for authorized training purposes. Contact paca511@eagereverest.com for inquiries.</p>
    """

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000)